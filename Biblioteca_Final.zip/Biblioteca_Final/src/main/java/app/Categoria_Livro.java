package app;

public class Categoria_Livro {

	private int id;
	private String categoria;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategoria() {
		return categoria;
	}
	
	//Criar um check com as categorias validas!!!
	
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	
	
}
